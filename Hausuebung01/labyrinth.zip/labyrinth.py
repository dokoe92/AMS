# Aufgabe 6: Zahlenlabyrinth als gerichteter Graph + Breitensuche (BFS)
#
# Idee:
#   Knoten  = Felder des Labyrinths, dargestellt als (zeile, spalte)
#   Kanten  = erlaubte Sprünge: Steht auf einem Feld die Zahl k, darf man
#             genau k Felder nach oben, unten, links oder rechts springen.
#   Der Graph ist gerichtet: Von A nach B springen heißt nicht,
#   dass man von B auch nach A zurückspringen kann.
#   Das Labyrinth ist lösbar, wenn es einen Weg vom Start zur Mitte gibt.

from collections import deque   # deque = Warteschlange (Queue) für die BFS


def lade_labyrinth(dateiname):
    """Liest Labyrinth.txt ein und gibt (spielfeld, startfeld) zurück."""
    with open(dateiname) as datei:
        # leere Zeilen weglassen, Leerzeichen am Rand entfernen
        textzeilen = [text.strip() for text in datei if text.strip() != ""]

    index_field = textzeilen.index("Field")   # Position der Überschrift "Field"
    index_start = textzeilen.index("Start")   # Position der Überschrift "Start"

    # Zwischen "Field" und "Start" stehen die Zeilen des Spielfelds,
    # z.B. "2,2,4,1,3" wird zur Liste [2, 2, 4, 1, 3]
    spielfeld = []
    for text in textzeilen[index_field + 1 : index_start]:
        zahlen_der_zeile = [int(zahl) for zahl in text.split(",")]
        spielfeld.append(zahlen_der_zeile)

    # Unter "Start" steht z.B. "4,2" = (Zeile 4, Spalte 2), Zählung ab 0
    start_zeile, start_spalte = textzeilen[index_start + 1].split(",")
    startfeld = (int(start_zeile), int(start_spalte))
    return spielfeld, startfeld


def nachfolger(spielfeld, aktuelles_feld):
    """Gibt alle Felder zurück, auf die man von 'aktuelles_feld' aus springen
    kann (= die ausgehenden Kanten, also die Nachfolger im gerichteten Graph)."""
    zeile, spalte = aktuelles_feld
    sprungweite = spielfeld[zeile][spalte]   # Zahl auf dem Feld = Sprungweite

    if sprungweite == 0:                     # Zielfeld (0): hier geht es nicht weiter
        return []

    anzahl_zeilen = len(spielfeld)
    anzahl_spalten = len(spielfeld[0])

    # Die 4 möglichen Sprünge: oben, unten, links, rechts
    moegliche_spruenge = [
        (zeile - sprungweite, spalte),       # nach oben
        (zeile + sprungweite, spalte),       # nach unten
        (zeile, spalte - sprungweite),       # nach links
        (zeile, spalte + sprungweite),       # nach rechts
    ]

    # Nur Sprünge behalten, die im Spielfeld landen (nicht über den Rand)
    erlaubte_spruenge = []
    for neue_zeile, neue_spalte in moegliche_spruenge:
        zeile_ok = 0 <= neue_zeile < anzahl_zeilen
        spalte_ok = 0 <= neue_spalte < anzahl_spalten
        if zeile_ok and spalte_ok:
            erlaubte_spruenge.append((neue_zeile, neue_spalte))
    return erlaubte_spruenge


def breitensuche(spielfeld, startfeld, zielfeld):
    """BFS vom Startfeld aus. Gibt den kürzesten Weg als Liste von Feldern
    zurück oder None, wenn das Zielfeld nicht erreichbar ist."""

    # vorgaenger[feld] = Feld, von dem aus wir 'feld' zum ersten Mal erreicht
    # haben. Wer hier schon drin steht, gilt als "besucht".
    # Das Startfeld hat keinen Vorgänger (None).
    vorgaenger = {startfeld: None}

    # Warteschlange: vorne wird entnommen, hinten wird eingefügt.
    # Dadurch werden die Felder in der Reihenfolge ihrer Entfernung
    # zum Start bearbeitet (erst alle mit 1 Sprung, dann mit 2, ...).
    warteschlange = deque([startfeld])

    while len(warteschlange) > 0:
        aktuelles_feld = warteschlange.popleft()     # vorderstes Feld entnehmen

        if aktuelles_feld == zielfeld:               # Ziel gefunden -> fertig
            break

        # (4,3)Nachfolger (4,2) Vorgänger
        # Vorgänger vom Nachfolger
        # Vorgänger = aktuelles_feld
        for naechstes_feld in nachfolger(spielfeld, aktuelles_feld):
            if naechstes_feld not in vorgaenger:     # noch nie besucht?
                vorgaenger[naechstes_feld] = aktuelles_feld  # merken, woher wir kamen
                warteschlange.append(naechstes_feld)         # hinten anstellen

    if zielfeld not in vorgaenger:                   # Ziel nie erreicht -> unlösbar
        return None

    # Weg rekonstruieren: vom Zielfeld über die Vorgänger zurück zum Start,
    # danach umdrehen, damit der Weg vom Start zum Ziel läuft.
    weg = []
    feld_auf_dem_weg = zielfeld
    while feld_auf_dem_weg is not None:
        weg.append(feld_auf_dem_weg)
        feld_auf_dem_weg = vorgaenger[feld_auf_dem_weg]
    weg.reverse()
    return weg


def ist_loesbar(spielfeld, startfeld):
    """Methode zur Lösbarkeitsprüfung: Gibt es einen Weg Start -> Mitte?"""
    mittelfeld = (len(spielfeld) // 2, len(spielfeld[0]) // 2)
    return breitensuche(spielfeld, startfeld, mittelfeld) is not None


# ----------------------------------------------------------------------
# Hauptprogramm: Labyrinth.txt laden, lösen und ein paar Tests ausgeben
# ----------------------------------------------------------------------
if __name__ == "__main__":
    spielfeld, startfeld = lade_labyrinth("Labyrinth.txt")
    zielfeld = (len(spielfeld) // 2, len(spielfeld[0]) // 2)

    weg = breitensuche(spielfeld, startfeld, zielfeld)
    print("Start:", startfeld, " Ziel:", zielfeld)
    if weg is None:
        print("Das Labyrinth ist NICHT lösbar.")
    else:
        print("Das Labyrinth ist lösbar. Kürzester Weg:", len(weg) - 1, "Züge")
        print(weg)

    # Tests mit anderen Spielfeldern (auch nicht quadratisch)
    print("\nTests:")
    tests = [
        ("3x3 nur Einsen, Mitte = 0",
         [[1, 1, 1], [1, 0, 1], [1, 1, 1]], (0, 0)),
        ("3x3 nur Zweien, Mitte = 0",
         [[2, 2, 2], [2, 0, 2], [2, 2, 2]], (0, 0)),
        ("3x5 nicht quadratisch",
         [[1, 1, 1, 1, 1], [1, 1, 0, 1, 1], [1, 1, 1, 1, 1]], (0, 0)),
        ("5x3 nicht quadratisch",
         [[2, 1, 2], [1, 2, 1], [2, 0, 2], [1, 2, 1], [2, 1, 2]], (0, 0)),
    ]
    for testname, test_spielfeld, test_startfeld in tests:
        print(testname, "-> lösbar:", ist_loesbar(test_spielfeld, test_startfeld))
