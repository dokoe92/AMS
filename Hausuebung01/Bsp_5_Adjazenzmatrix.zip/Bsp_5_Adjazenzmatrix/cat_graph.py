"""
HÜ01 - Aufgabe 5: Adjazenzmatrizen (Aurelias Sprunggraph)

Ablauf:
  1. Adjazenzmatrix aus CatNodes.csv einlesen
  2. Prüfen, ob der Graph ungerichtet ist (Matrix symmetrisch?)
  3. Ordnung (Anzahl Knoten) und Größe (Anzahl Kanten) bestimmen
  4. Grad jedes Knotens berechnen und die Knoten mit dem größten Grad finden
  5. Graph als Graphviz-Datei (CatGraph.dot) speichern
"""
import csv

# ---------------------------------------------------------------------------
# 1. Adjazenzmatrix einlesen
# ---------------------------------------------------------------------------
# Aufbau der CSV-Datei (Trennzeichen ";"):
#   erste Zeile:     leeres Feld, danach alle Ortsnamen
#   weitere Zeilen:  Ortsname, danach 0 oder 1 für jede Spalte
# Eine 1 in Zeile "A" und Spalte "B" bedeutet: Die Katze kann von A nach B springen.

with open("CatNodes.csv", encoding="utf-8") as datei:
    zeilen = list(csv.reader(datei, delimiter=";"))

knoten = zeilen[0][1:]  # Ortsnamen aus der Kopfzeile (erstes Feld ist leer)

matrix = []
for zeile in zeilen[1:]:
    werte = [int(eintrag) for eintrag in zeile[1:]]  # Ortsname am Anfang weglassen
    matrix.append(werte)

anzahl_knoten = len(knoten)

# ---------------------------------------------------------------------------
# 2. Ist der Graph ungerichtet?
# ---------------------------------------------------------------------------
# Ein Graph ist ungerichtet, wenn jede Kante in beide Richtungen geht.
# In der Matrix heißt das: matrix[i][j] == matrix[j][i] für alle i, j
# (die Matrix ist symmetrisch).

ist_symmetrisch = True
for i in range(anzahl_knoten):
    for j in range(anzahl_knoten):
        if matrix[i][j] != matrix[j][i]:
            ist_symmetrisch = False
            print(f"Nicht symmetrisch: {knoten[i]} -> {knoten[j]}, aber nicht zurück")

print("1) Ist der Graph ungerichtet?")
if ist_symmetrisch:
    print("   Ja, die Matrix ist symmetrisch: Jeder Sprung ist auch zurück möglich.")
else:
    print("   Nein, die Matrix ist nicht symmetrisch.")
print()

# ---------------------------------------------------------------------------
# 3. Ordnung und Größe
# ---------------------------------------------------------------------------
# Ordnung = Anzahl der Knoten
# Größe   = Anzahl der Kanten
# Jede ungerichtete Kante {A, B} steht ZWEIMAL in der Matrix
# (bei A -> B und bei B -> A), deshalb wird die Anzahl der Einsen halbiert.

anzahl_einsen = 0
for zeile in matrix:
    anzahl_einsen += sum(zeile)

ordnung = anzahl_knoten
groesse = anzahl_einsen // 2

print("2) Ordnung und Größe")
print(f"   Ordnung = Anzahl Knoten = {ordnung}")
print(f"   Größe   = Anzahl Einsen / 2 = {anzahl_einsen} / 2 = {groesse}")
print()

# ---------------------------------------------------------------------------
# 4. Grade und Knoten mit dem größten Grad
# ---------------------------------------------------------------------------
# Der (Ausgangs-)Grad eines Knotens = Anzahl seiner Nachbarn
#                                  = Summe seiner Zeile in der Matrix.

grad = {}
for i in range(anzahl_knoten):
    grad[knoten[i]] = sum(matrix[i])

print("3) Grad jedes Knotens")
for ort in knoten:
    print(f"   {ort:<28} {grad[ort]}")
print()

groesster_grad = max(grad.values())

beste_schlafplaetze = []
for ort in knoten:
    if grad[ort] == groesster_grad:
        beste_schlafplaetze.append(ort)

print(f"4) Größter Grad = {groesster_grad}, beste Schlafplätze:")
for ort in beste_schlafplaetze:
    print(f"   - {ort}")
print()

# ---------------------------------------------------------------------------
# 5. Visualisierung als Graphviz-Datei
# ---------------------------------------------------------------------------
# "graph" = ungerichteter Graph, Kanten werden mit "--" geschrieben.
# Jede Kante wird nur einmal eingetragen (nur j > i), sonst wäre sie doppelt.
# Die besten Schlafplätze werden orange eingefärbt.

dot_zeilen = ["graph CatGraph {"]
dot_zeilen.append("  layout=neato; overlap=false;")
dot_zeilen.append("  node [style=filled, fillcolor=lightgrey];")

for ort in beste_schlafplaetze:
    dot_zeilen.append(f'  "{ort}" [fillcolor=orange];')

for i in range(anzahl_knoten):
    for j in range(i + 1, anzahl_knoten):
        if matrix[i][j] == 1:
            dot_zeilen.append(f'  "{knoten[i]}" -- "{knoten[j]}";')

dot_zeilen.append("}")

with open("CatGraph.dot", "w", encoding="utf-8") as datei:
    datei.write("\n".join(dot_zeilen))

print("5) Graph gespeichert in CatGraph.dot")
print("   Bild erzeugen mit: neato -Tpng CatGraph.dot -o CatGraph.png")
